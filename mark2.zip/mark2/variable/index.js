// var vs let vs const

//  In JavaScript, variables are used to store and manage data.
//  They are like containers or placeholders for values, which can be numbers, strings, objects, functions, and more.
//   Variables are an essential concept in programming and allow you to work with data in your code.
