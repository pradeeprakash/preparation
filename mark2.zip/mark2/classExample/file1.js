const Singleton = require("./singleTon");

const ob = new Singleton();

ob.someMethod();

18001234;
